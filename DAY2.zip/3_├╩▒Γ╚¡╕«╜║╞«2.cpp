#include <string>

int main()
{
	int a = 10;
	int b;
	b = 10;

	//-------------------------
	std::string s1 = "hello";

	std::string s2;
	s2 = "hello";


}