﻿// 예제1     149 page ~
#include <iostream>
#include <vector>

int main()
{
}



