﻿// 3_정적멤버1 - 110 page
#include <iostream>

class Car
{
	int color;
	int speed;
public:
	Car()  {  }
	~Car() {  }
};

int main()
{
	Car c1;
	Car c2;
}

