#include <iostream>
#include <vector>

int main()
{
	std::vector<int> v1(10, 3);
	std::vector<int> v2 = { 1,2,3,4,5 };

	
}
