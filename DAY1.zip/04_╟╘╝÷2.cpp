﻿#include <cstdio>
// 37 page ~

int square(int a)
{
	return a * a;
}
int main()
{
	square(3);
	square(3.4);
}
