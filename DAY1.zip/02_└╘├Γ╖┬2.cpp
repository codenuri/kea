﻿// 3_입출력2.cpp - 18 page
#include <iostream>

int main()
{
	int n = 10;
	std::cout << n << std::endl; // 
	std::cout << n << std::endl; // 
	std::cout << n << std::endl; // 
	std::cout << n << std::endl; // 
}
