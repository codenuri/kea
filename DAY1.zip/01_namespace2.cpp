﻿// namespace 에 있는 함수는 접근하는 방법 - 8 page
